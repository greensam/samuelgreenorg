#include <stdio.h>

int main(void){
    
    int x = 2, y = 8, z = 12;
    
    int* ptr_x = &x;
    int* ptr_y = &y;
    int* ptr_z = &z;
    
    printf("The value of x is: %i\n", x);
    printf("The address of x is: %p\n", &x);
    printf("The value of ptr_x is: %p\n", ptr_x);
    printf("The address of ptr_x is: %p\n", &ptr_x);
    printf("The ptr_x points to the value: %i\n", *ptr_x);
    
    printf("\n");
    
    // multiplication
    printf("z = x*y\n");
    z = x * y;
    printf("z =  %i\n", z);
    
    printf("\n");
    
    // multipliciation
    printf("x *= y\n");
    x *= y;
    printf("x = %i\n", x);
    
    printf("\n");

    // change
    printf("y = %i\n", y);
    printf("y = *ptr_x\n");
    y = *ptr_x;
    printf("y = %i\n", y);
    
    printf("\n");

    
    printf("*ptr_x = x * y\n");;
    *ptr_x = x * y;
    printf("*ptr_x = %i\n", *ptr_x);
    printf("x = %i\n", x);
    
    printf("ptr_x = ptr_y\n");
    printf("ptr_x = %p\n", ptr_x);
    printf("ptr_y = %p\n", ptr_y);
    printf("x = %i\n", x);
    printf("y = %i\n", y);
    printf("*ptr_x = %i\n", *ptr_x);
    printf("*ptr_y = %i\n", *ptr_y);
    
    printf("x = (*ptr_y) * (*ptr_z)\n");
    x = (*ptr_y) * (*ptr_z);
    printf("x = %i\n", x);

    
}