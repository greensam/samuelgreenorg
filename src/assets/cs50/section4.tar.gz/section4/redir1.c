#include <stdio.h>

int main(void){
    printf("HELLO THIS IS A REDIRECTION EXAMPLE!\n");
}