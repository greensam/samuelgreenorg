#include <stdio.h>
#include <cs50.h>

int main(void){
    string x = GetString();
    printf("HELLO THIS IS ANOTHER REDIRECTION EXAMPLE!\n");
    printf("HERE's YOUR STRING: %s\n", x);
}