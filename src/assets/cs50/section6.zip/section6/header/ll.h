#include <stdio.h>

typedef struct x {
    int i;
    struct x* next;

} node;

node* make_node(int i);

void free_list(node* head);

void walk_list(node* start);