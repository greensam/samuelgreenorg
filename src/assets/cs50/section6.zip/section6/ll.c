#include <stdio.h>
#include <stdlib.h>
#include "header/ll.h"

int main(void){
    
    node* head = NULL;
    
    for (int i = 0; i < 100; i++){
        node* new = make_node(i);
        if (head != NULL){
            new->next = head;
            head = new;
        }
    }
    
    walk_list(head);
    
    free_list(head);
}

node* make_node(int i)
{
    printf("CREATING A NODE CONTAINING: %i\n", i);
    node* new_node = (node*) malloc(sizeof(node));
    if (new_node != NULL){
        new_node->i = i;
        new_node->next = NULL;
    }
    else
    {
        return NULL;
    }
    return new_node;
}

void free_list(node* head)
{
    node* current = head;
    while (current != NULL){
        node* tmp = current;
        current = current->next;
        printf("FREEING A NODE CONTAINING: %i\n", tmp->i);
        free(tmp);
    }
}

void walk_list(node* start){
    node* current = start;
    
    while (current != NULL){
        printf("ITERATING A NODE WITH: %i\n", current->i);
        current = current->next;
    }
}