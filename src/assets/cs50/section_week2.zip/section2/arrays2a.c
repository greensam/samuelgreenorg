#include <cs50.h>
#include <stdio.h>

int main(void){
    
    int nums[10];
    
    for (int i = 0; i < 10; i++)
    {
        nums[i] = 10 + i;
        printf("%i\n", nums[i]);
    }
    
    // for (int i = 0; i < 10; i++)
    // {
    //     printf("%i\n", nums[i]);
    // }
    
}