#include <stdio.h>
#include <cs50.h>
#include <string.h>

string one(void);
string two(void);


int main(int argc, string argv[]){
    if (argc != 2)
    {
        return 1; 
    }
    else
    {
        if (strcmp(argv[1], "one") == 0)
        {
            printf("Passed in one\n");
            printf("%s\n", one());
        }
        else if (strcmp(argv[1], "two") == 0)
        {
            printf("Passed in two\n");
            printf("%s\n", two());
        }
        else 
        {
            printf("Wrong argument!\n");
        }
    }
}

string one(void){
    return "This is function one!";
}

string two(void){
    return "This is function two!";
}