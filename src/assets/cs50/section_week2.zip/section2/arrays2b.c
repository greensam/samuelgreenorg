#include <stdio.h>
#include <cs50.h>
#include <string.h>

int main(void){
    
    string welcome = "Welcome to CS50! Woo!";
    
    for (int i = 0, n = strlen(welcome); i<n; i++){
        printf("%c\n", welcome[i]);
    }
    
}