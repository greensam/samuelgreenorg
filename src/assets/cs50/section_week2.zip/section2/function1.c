#include <stdio.h>
#include <cs50.h>

int greet(string name);

int main(void){
    printf("Please enter your name: ");
    string name = GetString();
    
    int result = greet(name);
    printf("The result is %i\n", result);
    
    // how about printf("The result is %i\n", greet(name);?
}

int greed(string name){
    printf("Hi %s, this is my first function!", name);
    return 1
}