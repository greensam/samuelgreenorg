#include <cs50.h>
#include <stdio.h>

int main(void){
    string strings[] = {"hi", "my", "name", "is", "sam", "this", "is", "cs", "50!"};
    
    for (int i = 0; i < 9; i ++){
        printf("strings[%i] %s\n", i, strings[i]);
    }
        
}