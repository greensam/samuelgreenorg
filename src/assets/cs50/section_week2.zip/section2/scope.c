#include <stdio.h>

// prototypes
// void scope1(void);
void scope2(void);

int a = 5;

int main(void)
{
    // scope1();
    scope2();
    a = 5;
}

// scope decided by parantheses


// scope decided by priority
void scope2(void)
{
    a = 4;
    (void) a; // this should be a hint

    int a = 0;
    printf("%d\n", a); // what will this print?
}