/**
 * scripts.js
 *
 * Samuel Green & You
 * Computer Science 50
 * Section 9
 *
 * Global JavaScript
 */

$(function(){
    // Part 1
    /**
     * Add an alert when the user clicks on the button.
     */


    // Part 2
    /**
     * Change the previous alert so that
     * it displays the username and password currently entered into the boxes.
     */

    // Part 3
    /**
     * Change the previous function so that it sets the header of the page
     * to be the text the user entered in the username box *if it is not empty.*
     */
})


 