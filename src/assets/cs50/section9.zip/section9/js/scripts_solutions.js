/**
 * scripts.js
 *
 * Samuel Green & You
 * Computer Science 50
 * Section 9
 *
 * Global JavaScript
 */

// Part 1
// Add an alert when the user clicks 
document.getElementById("submit_btn").onclick = function() {
    alert("Clicked!");
};

// Part 2
/**
 * change the previous function so that the alert shows
 *  the text currently inside of the textboxes
 */
document.getElementById("submit_btn").onclick = function(){
    var un = document.getElementsByName("username")[0].value;
    var pw = document.getElementsByName("password")[0].value;
    alert(un + " " + pw);
}

// Part 3
document.getElementById("submit_btn").onclick = function(){
    var un = document.getElementsByName("username")[0].value;
    if (un !== ""){
        document.getElementById("page_title").innerHTML = un;
    }
}