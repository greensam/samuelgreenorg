/**
 * Samuel Green & You
 * Computer Science 50
 * Section 9
 * 
 * Practice with Ajax
 * 
 */

$(function(){
    console.log("echo");
    $("body").append("<div id = 'ajax_resp'></div>");
        
    var root = 'http://jsonplaceholder.typicode.com';
    
    $("#submit_btn").click(function(){
    	console.log("clicked");
	    $.ajax({url: root + '/posts/' + Math.round(50*Math.random()).toString(),
	            method: 'GET'
	            }).then(function(data) {
	            	console.log(data);
	                $("#ajax_resp").html(data.body);
	            });
	 });
})