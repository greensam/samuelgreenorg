#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(int argc, string argv[]){
    
    if (argc == 2){
        printf("Oh no! Wrong number of arguments!");
        return 1;
    }
    
    int k = atoi(argv[1]);
    
    string text = GetString();
    
    for (int i = 0, n = strlen(text); i<n;  i = i + 2)
    {
        
        if (islower(text[i]))
        {
            printf("%c", (text[i] - 'a' + k) % 26 + 'a');
        }
        else if (isupper(text[i]))
        {
            printf("%c", (text[k] - 'A' + k) % 26 + 'A');
        } 
        else 
        {
            printf("%c", text[i]);
        }
    }
    
    
}