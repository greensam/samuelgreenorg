#include <stdio.h>

bool search(int n, int nums[], int needle);

int main(void){
    int n = 10;
    int nums = {1,2,3,4,5,6,10,11,15,20};
    
    printf("%b", search(10, nums, 11));
        printf("%b", search(10, nums, 19));

}

bool search(int n, int nums[], int needle){
    int left = 0;
    int right = n - 1;
    int mid = (left + right) / 2;
    
    while (// TODO during section, solutions posted later!)
    {
        // fill in here
    }
    return false
}